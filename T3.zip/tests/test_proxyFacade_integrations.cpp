#include "third_party/doctest.h"

#include "../include/SecureWorkflowProxy.h"
#include "../include/TIVIDYFacade.h"
#include "../include/WorkflowDefinition.h"
#include "../include/SequentialStage.h"
#include "../include/Task.h"
#include "../include/Role.h"
#include "../include/Participant.h"

#include <stdexcept>
#include <string>
#include <vector>

/*
 * Integration tests for SecureWorkflowProxy -> TIVIDYFacade.
 *
 * The facade owns registered WorkflowDefinition and Participant objects.
 * The Role is deliberately declared before the facade in each test so that
 * it outlives the facade and its participants.
 */

namespace {

struct ProxyFacadeFixture {
    Role workerRole;
    TIVIDYFacade facade;
    SecureWorkflowProxy proxy;

    ProxyFacadeFixture()
        : workerRole("WorkflowWorker", 1),
          facade(),
          proxy(&facade) {

        workerRole.addPermission("workflow.start");
        workerRole.addPermission("task.assign");
        workerRole.addPermission("task.start");
        workerRole.addPermission("task.complete");
        workerRole.addPermission("task.reject");

        facade.registerParticipant(
            new Participant("worker-1", "Test Worker", &workerRole));

        WorkflowDefinition* definition =
            new WorkflowDefinition("IntegrationWorkflow", 1);

        SequentialStage* root =
            new SequentialStage("root", "Root Stage");

        root->add(new Task("task-1", "First Task", &workerRole, nullptr));

        definition->setRoot(root);
        facade.registerDefinition(definition);
    }

    std::string createStartedInstance() {
        const std::string instanceID =
            facade.createInstance("IntegrationWorkflow");

        proxy.startInstance(instanceID, "worker-1");
        return instanceID;
    }
};

} // namespace

TEST_CASE("Proxy forwards permitted workflow start to the Facade") {
    ProxyFacadeFixture fixture;

    const std::string instanceID =
        fixture.facade.createInstance("IntegrationWorkflow");

    const std::vector<std::string> before =
        fixture.facade.getAuditLog();

    CHECK_NOTHROW(
        fixture.proxy.startInstance(instanceID, "worker-1"));

    const std::vector<std::string> after =
        fixture.facade.getAuditLog();

    CHECK(after.size() > before.size());
}

TEST_CASE("Proxy denies workflow start without permission and leaves state unchanged") {
    Role restrictedRole("Restricted", 1);
    TIVIDYFacade facade;
    SecureWorkflowProxy proxy(&facade);

    facade.registerParticipant(
        new Participant("restricted-user", "Restricted User", &restrictedRole));

    WorkflowDefinition* definition =
        new WorkflowDefinition("RestrictedWorkflow", 1);
    SequentialStage* root =
        new SequentialStage("root", "Root Stage");
    root->add(new Task("task-1", "First Task", &restrictedRole, nullptr));
    definition->setRoot(root);
    facade.registerDefinition(definition);

    const std::string instanceID =
        facade.createInstance("RestrictedWorkflow");

    const std::vector<std::string> before = facade.getAuditLog();

    CHECK_THROWS_AS(
        proxy.startInstance(instanceID, "restricted-user"),
        std::runtime_error);

    // The proxy rejects the request before forwarding it to the Facade.
    CHECK(facade.getAuditLog().size() == before.size());
}

TEST_CASE("Proxy forwards permitted assignment and task lifecycle calls to the Facade") {
    ProxyFacadeFixture fixture;

    const std::string instanceID =
        fixture.facade.createInstance("IntegrationWorkflow");

    fixture.proxy.startInstance(instanceID, "worker-1");

    // The same participant has task.assign permission and is assigning the
    // task to themselves. The Proxy forwards this call to the Facade.
    CHECK_NOTHROW(
        fixture.proxy.assignTask(
            instanceID, "task-1", "worker-1", "worker-1"));

    // Ownership is now established, so the Proxy permits task operations.
    CHECK(fixture.facade.isTaskAssignedTo(
        instanceID, "task-1", "worker-1"));

    CHECK_NOTHROW(
        fixture.proxy.startTask(instanceID, "task-1", "worker-1"));

    CHECK_NOTHROW(
        fixture.proxy.completeTask(instanceID, "task-1", "worker-1"));

    // A completed task should no longer be available for another start.
    // The Facade's command/state implementation is the source of truth.
    CHECK_THROWS(
        fixture.proxy.startTask(instanceID, "task-1", "worker-1"));
}

TEST_CASE("Proxy denies task operation by a participant who does not own the task") {
    ProxyFacadeFixture fixture;

    Role otherRole("OtherWorker", 1);
    otherRole.addPermission("task.start");
    otherRole.addPermission("task.complete");

    fixture.facade.registerParticipant(
        new Participant("worker-2", "Other Worker", &otherRole));

    const std::string instanceID =
        fixture.facade.createInstance("IntegrationWorkflow");

    fixture.proxy.startInstance(instanceID, "worker-1");
    fixture.proxy.assignTask(
        instanceID, "task-1", "worker-1", "worker-1");

    const std::vector<std::string> before =
        fixture.facade.getAuditLog();

    CHECK_THROWS_AS(
        fixture.proxy.startTask(instanceID, "task-1", "worker-2"),
        std::runtime_error);

    // A denied ownership check must not reach the Facade or change its log.
    CHECK(fixture.facade.getAuditLog().size() == before.size());

    CHECK(fixture.facade.isTaskAssignedTo(
        instanceID, "task-1", "worker-1"));
}

TEST_CASE("Proxy denial for task completion does not change workflow state") {
    Role assignOnlyRole("AssignOnly", 1);
    assignOnlyRole.addPermission("workflow.start");
    assignOnlyRole.addPermission("task.assign");

    TIVIDYFacade facade;
    SecureWorkflowProxy proxy(&facade);

    facade.registerParticipant(
        new Participant("assigner", "Task Assigner", &assignOnlyRole));

    WorkflowDefinition* definition =
        new WorkflowDefinition("NoCompletePermissionWorkflow", 1);
    SequentialStage* root =
        new SequentialStage("root", "Root Stage");
    root->add(new Task("task-1", "First Task", &assignOnlyRole, nullptr));
    definition->setRoot(root);
    facade.registerDefinition(definition);

    const std::string instanceID =
        facade.createInstance("NoCompletePermissionWorkflow");

    proxy.startInstance(instanceID, "assigner");
    proxy.assignTask(instanceID, "task-1", "assigner", "assigner");

    const std::vector<std::string> before = facade.getAuditLog();

    CHECK_THROWS_AS(
        proxy.completeTask(instanceID, "task-1", "assigner"),
        std::runtime_error);

    CHECK(facade.getAuditLog().size() == before.size());
    CHECK(facade.isTaskAssignedTo(instanceID, "task-1", "assigner"));
}
