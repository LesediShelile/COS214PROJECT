/**
 * @file test_proxy_facade_end_to_end.cpp
 * @brief End-to-end scenarios that drive the whole stack through
 *        SecureWorkflowProxy -> TIVIDYFacade -> engine, for TWO industries
 *        that reuse the same engine classes unchanged.
 *
 *  Industry 1 (Healthcare): hospital admission, parallel intake tasks + approval.
 *  Industry 2 (Insurance) : claim assessment, sequential stage.
 *
 * The final suite "KNOWN GAPS" holds tests of INTENDED behaviour that the current
 * engine does not yet deliver. They are tagged doctest::may_fail() so they are
 * reported but do not break the build; remove the decorator once fixed.
 */
#include "third_party/doctest.h"
#include "third_party/TestSupport.h"

using namespace testsupport;

namespace {

/** Healthcare cast + definition: parallel intake with a Doctor-level approval chain. */
struct Hospital {
    Fixture f;
    Role nurse, doctor, clerk;
    SecureWorkflowProxy proxy;
    std::string id;

    Hospital() : nurse("nurse", 2), doctor("doctor", 3), clerk("clerk", 1), proxy(&f.facade) {
        nurse.addPermission("task.start");
        nurse.addPermission("task.complete");
        nurse.addPermission("task.reject");
        nurse.addPermission("approval.request");
        doctor.addPermission("task.start");
        doctor.addPermission("task.complete");
        doctor.addPermission("approval.request");
        clerk.addPermission("workflow.start");
        clerk.addPermission("task.assign");
        f.facade.registerParticipant(new Participant("nancy", "Nurse Nancy", &nurse));
        f.facade.registerParticipant(new Participant("drdave", "Dr Dave", &doctor));
        f.facade.registerParticipant(new Participant("clark", "Clerk Clark", &clerk));

        DefinitionBuilder b;
        b.reset("hospital-admission", 1);
        b.beginParallelStage("Intake");
        b.addTask("Triage", &nurse, nullptr);   b.withAudit(nullptr); b.commitPendingTask(); // 1
        b.addTask("Consult", &doctor, nullptr); b.withAudit(nullptr); b.commitPendingTask(); // 2
        b.addTask("Billing", &clerk, nullptr);  b.withAudit(nullptr); b.commitPendingTask(); // 3
        b.endStage();
        WorkflowDefinition* def = b.getResult();
        def->getRoot()->getChildren()[1]->setData("requiredApprovalLevel", "3");
        def->setApprovalChain(makeApprovalChain(&f.nurseRole /*1*/, &doctor /*3*/));
        f.facade.registerDefinition(def);
        id = f.facade.createInstance("hospital-admission");
    }
};

/** Insurance claim: sequential stage of three tasks. */
struct Insurance {
    Fixture f;
    SecureWorkflowProxy proxy;
    std::string id;
    Insurance() : proxy(&f.facade) {
        f.facade.registerDefinition(makeSequentialDefinition("insurance-claim", &f.workerRole, 3));
        id = f.facade.createInstance("insurance-claim");
    }
};

} // namespace

TEST_SUITE("E2E: healthcare (completion path)") {

TEST_CASE("clerk starts, assigns; staff execute their own tasks; audit shows the whole story") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "1", "nancy", "clark");
    h.proxy.assignTask(h.id, "2", "drdave", "clark");
    h.proxy.assignTask(h.id, "3", "clark", "clark");

    h.proxy.startTask(h.id, "1", "nancy");
    h.proxy.completeTask(h.id, "1", "nancy");
    h.proxy.startTask(h.id, "2", "drdave");
    CHECK(h.proxy.requestApproval(h.id, "2", "drdave") == ApprovalStatus::Approved);
    h.proxy.completeTask(h.id, "2", "drdave");

    std::vector<std::string> log = h.f.facade.getAuditLog();
    CHECK(countContaining(log, "became available") == 3);
    CHECK(countContaining(log, "was assigned") == 3);
    CHECK(countContaining(log, "was completed") == 2);
    CHECK(contains(h.f.facade.getMetricsSummary(), "Transitions"));
}

TEST_CASE("the approval chain escalates the high-risk task to the doctor") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "2", "drdave", "clark");
    // required level 3 > chain head authority 1 -> escalated to the doctor level -> approved
    CHECK(h.proxy.requestApproval(h.id, "2", "drdave") == ApprovalStatus::Approved);
}

} // TEST_SUITE

TEST_SUITE("E2E: healthcare (exception and security paths)") {

TEST_CASE("a nurse cannot start the workflow or assign work (privilege boundaries)") {
    Hospital h;
    CHECK_THROWS_AS(h.proxy.startInstance(h.id, "nancy"), std::runtime_error);
    h.proxy.startInstance(h.id, "clark");
    CHECK_THROWS_AS(h.proxy.assignTask(h.id, "1", "nancy", "nancy"), std::runtime_error);
}

TEST_CASE("a doctor cannot reject (lacks 'task.reject') even on their own task") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "2", "drdave", "clark");
    CHECK_THROWS_AS(h.proxy.rejectTask(h.id, "2", "no", "drdave"), std::runtime_error);
}

TEST_CASE("rejection exception path: nurse rejects triage, others carry on") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "1", "nancy", "clark");
    h.proxy.assignTask(h.id, "2", "drdave", "clark");
    h.proxy.rejectTask(h.id, "1", "patient left", "nancy");

    // rejected task is final for the old owner
    CHECK_THROWS_AS(h.proxy.completeTask(h.id, "1", "nancy"), std::runtime_error);
    // sibling continues
    h.proxy.startTask(h.id, "2", "drdave");
    CHECK_NOTHROW(h.proxy.completeTask(h.id, "2", "drdave"));
    CHECK(countContaining(h.f.facade.getAuditLog(), "'Triage' was rejected: patient left") == 1);
}

TEST_CASE("a nurse cannot hijack a doctor's task") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "2", "drdave", "clark");
    CHECK_THROWS_AS(h.proxy.startTask(h.id, "2", "nancy"), std::runtime_error);
    CHECK_THROWS_AS(h.proxy.completeTask(h.id, "2", "nancy"), std::runtime_error);
}

TEST_CASE("misassignment is recoverable with undo, then the right person is assigned") {
    Hospital h;
    h.proxy.startInstance(h.id, "clark");
    h.proxy.assignTask(h.id, "2", "nancy", "clark");        // wrong person
    CHECK(h.f.facade.undoLastAction());
    h.proxy.assignTask(h.id, "2", "drdave", "clark");       // right person
    CHECK_THROWS_AS(h.proxy.startTask(h.id, "2", "nancy"), std::runtime_error);
    CHECK_NOTHROW(h.proxy.startTask(h.id, "2", "drdave"));
}

} // TEST_SUITE

TEST_SUITE("E2E: insurance (second industry, same engine)") {

TEST_CASE("first claim task runs end to end through the proxy") {
    Insurance ins;
    ins.proxy.startInstance(ins.id, "mgr");
    ins.proxy.assignTask(ins.id, "1", "alice", "mgr");
    ins.proxy.startTask(ins.id, "1", "alice");
    ins.proxy.completeTask(ins.id, "1", "alice");
    CHECK(countContaining(ins.f.facade.getAuditLog(), "'Task1' was completed") == 1);
}

TEST_CASE("later claim tasks stay locked until the earlier one is done") {
    Insurance ins;
    ins.proxy.startInstance(ins.id, "mgr");
    CHECK_THROWS_AS(ins.proxy.assignTask(ins.id, "2", "alice", "mgr"), std::logic_error);
    CHECK_THROWS_AS(ins.proxy.assignTask(ins.id, "3", "alice", "mgr"), std::logic_error);
}

TEST_CASE("claim rejected by the assessor") {
    Insurance ins;
    ins.proxy.startInstance(ins.id, "mgr");
    ins.proxy.assignTask(ins.id, "1", "alice", "mgr");
    ins.proxy.rejectTask(ins.id, "1", "fraud suspected", "alice");
    CHECK(ins.f.facade.getAuditLog().back() == "'Task1' was rejected: fraud suspected (now Rejected)");
}

TEST_CASE("both industries run side by side in ONE facade without interfering") {
    Fixture f;
    SecureWorkflowProxy proxy(&f.facade);
    f.facade.registerDefinition(makeParallelDefinition("hospital-admission", &f.workerRole, 2));
    f.facade.registerDefinition(makeSequentialDefinition("insurance-claim", &f.workerRole, 2));
    std::string h = f.facade.createInstance("hospital-admission");
    std::string i = f.facade.createInstance("insurance-claim");
    proxy.startInstance(h, "mgr");
    proxy.startInstance(i, "mgr");

    proxy.assignTask(h, "1", "alice", "mgr");
    proxy.assignTask(i, "1", "bob", "mgr");
    CHECK_THROWS_AS(proxy.startTask(h, "1", "bob"), std::runtime_error);    // bob owns i:1, not h:1
    CHECK_THROWS_AS(proxy.startTask(i, "1", "alice"), std::runtime_error);
    proxy.startTask(h, "1", "alice");
    proxy.startTask(i, "1", "bob");
    proxy.completeTask(h, "1", "alice");
    // insurance task untouched by the hospital completion
    CHECK_THROWS_AS(proxy.completeTask(h, "1", "alice"), std::logic_error);
    CHECK_NOTHROW(proxy.completeTask(i, "1", "bob"));
}

} // TEST_SUITE

TEST_SUITE("E2E: stress and robustness") {

TEST_CASE("100 independent instances driven to completion of their first task") {
    Fixture f;
    SecureWorkflowProxy proxy(&f.facade);
    f.facade.registerDefinition(makeParallelDefinition("par", &f.workerRole, 3));
    std::vector<std::string> ids;
    for (int n = 0; n < 100; ++n) ids.push_back(f.facade.createInstance("par"));
    for (std::size_t n = 0; n < ids.size(); ++n) {
        proxy.startInstance(ids[n], "mgr");
        proxy.assignTask(ids[n], "1", "alice", "mgr");
        proxy.startTask(ids[n], "1", "alice");
        proxy.completeTask(ids[n], "1", "alice");
    }
    CHECK(countContaining(f.facade.getAuditLog(), "was completed") == 100);
    CHECK(ids.front() == "INST-1");
    CHECK(ids.back() == "INST-100");
}

TEST_CASE("repeated denied attempts never corrupt state") {
    Fixture f;
    SecureWorkflowProxy proxy(&f.facade);
    std::string id = f.startedInstance();
    const std::size_t before = f.facade.getAuditLog().size();
    for (int n = 0; n < 200; ++n) {
        CHECK_THROWS(proxy.assignTask(id, "1", "alice", "gina"));
        CHECK_THROWS(proxy.startTask(id, "1", "alice"));        // alice not owner yet
        CHECK_THROWS(proxy.startInstance(id, "alice"));
    }
    CHECK(f.facade.getAuditLog().size() == before);
    CHECK_NOTHROW(proxy.assignTask(id, "1", "alice", "mgr"));   // system still healthy
}

TEST_CASE("very long and odd identifiers are handled without crashing") {
    Fixture f;
    SecureWorkflowProxy proxy(&f.facade);
    const std::string huge(10000, 'z');
    const std::string odd = std::string("a\0b", 3) + "\n\t\"'";
    CHECK_THROWS_AS(proxy.startInstance(huge, "mgr"), std::invalid_argument);
    CHECK_THROWS_AS(proxy.startInstance(huge, huge), std::runtime_error);
    CHECK_THROWS_AS(proxy.startInstance(odd, odd), std::runtime_error);
    CHECK_THROWS_AS(f.facade.createInstance(huge), std::invalid_argument);
}

} // TEST_SUITE

// ===========================================================================
// KNOWN GAPS: intended behaviour that the current engine does NOT deliver.
// Root cause (see report): nothing ever publishes EventType::ITEM_COMPLETED, so
// EngineRouter::update() never calls WorkflowInstance::activateNext().
// ===========================================================================
TEST_SUITE("KNOWN GAPS: engine routing") {

TEST_CASE("completing a sequential task makes the NEXT task available" * doctest::may_fail()) {
    Fixture f;
    std::string id = f.startedInstance("seq", 2);
    f.facade.assignTask(id, "1", "alice");
    f.facade.startTask(id, "1");
    f.facade.completeTask(id, "1");
    CHECK_NOTHROW(f.facade.assignTask(id, "2", "alice"));   // Task2 should now be Available
}

TEST_CASE("the audit log announces the next task once the previous one completes" * doctest::may_fail()) {
    Fixture f;
    std::string id = f.startedInstance("seq", 2);
    f.facade.assignTask(id, "1", "alice");
    f.facade.startTask(id, "1");
    f.facade.completeTask(id, "1");
    CHECK(countContaining(f.facade.getAuditLog(), "'Task2' became available") == 1);
}

TEST_CASE("a full sequential run through the proxy can be completed" * doctest::may_fail()) {
    Insurance ins;
    ins.proxy.startInstance(ins.id, "mgr");
    for (int t = 1; t <= 3; ++t) {
        const std::string task = std::to_string(t);
        ins.proxy.assignTask(ins.id, task, "alice", "mgr");
        ins.proxy.startTask(ins.id, task, "alice");
        ins.proxy.completeTask(ins.id, task, "alice");
    }
    CHECK(countContaining(ins.f.facade.getAuditLog(), "was completed") == 3);
}

TEST_CASE("finishing every task finishes the workflow (WORKFLOW_FINISHED reaches the audit log)" * doctest::may_fail()) {
    Fixture f;
    f.facade.registerDefinition(makeParallelDefinition("par", &f.workerRole, 1));
    std::string id = f.facade.createInstance("par");
    f.facade.startInstance(id);
    f.facade.assignTask(id, "1", "alice");
    f.facade.startTask(id, "1");
    f.facade.completeTask(id, "1");
    CHECK(countContaining(f.facade.getAuditLog(), "Completed") >= 2);   // task + workflow outcome
}

} // TEST_SUITE