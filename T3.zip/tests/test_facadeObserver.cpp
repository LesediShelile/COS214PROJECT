/**
 * @file test_facade_observer.cpp
 * @brief OBSERVER pattern behaviour reached through TIVIDYFacade.
 *
 * GoF mapping:
 *  - Subject           : EventPublisher (one per WorkflowInstance)
 *  - Observers         : AuditLogger, Notifier, MetricsCollector, EngineRouter
 *  - Concrete subject  : AuditedTask (decorator that publishes TASK_ACTION events)
 *
 * The facade owns one AuditLogger / MetricsCollector shared by ALL instances.
 */
#include "third_party/doctest.h"
#include "third_party/TestSupport.h"

using namespace testsupport;

TEST_SUITE("Facade/Observer: audit log") {

TEST_CASE("a fresh facade has an empty audit log and metrics summary") {
    Fixture f;
    CHECK(f.facade.getAuditLog().empty());
    CHECK(f.facade.getMetricsSummary().empty());
}

TEST_CASE("creating an instance (without starting it) produces no events") {
    Fixture f;
    f.newInstance();
    CHECK(f.facade.getAuditLog().empty());
}

TEST_CASE("events are recorded in chronological order") {
    Fixture f;
    std::string id = f.startedInstance();
    f.facade.assignTask(id, "1", "alice");
    f.facade.startTask(id, "1");
    f.facade.completeTask(id, "1");
    std::vector<std::string> log = f.facade.getAuditLog();
    REQUIRE(log.size() == 4);
    CHECK(contains(log[0], "became available"));
    CHECK(contains(log[1], "was assigned"));
    CHECK(contains(log[2], "was started"));
    CHECK(contains(log[3], "was completed"));
}

TEST_CASE("each record names the task and its resulting state") {
    Fixture f;
    std::string id = f.startedInstance();
    f.facade.assignTask(id, "1", "alice");
    CHECK(f.facade.getAuditLog().back() == "'Task1' was assigned (now Assigned)");
}

TEST_CASE("the rejection reason is part of the audit record") {
    Fixture f;
    std::string id = f.startedInstance();
    f.facade.rejectTask(id, "1", "insurance expired");
    CHECK(f.facade.getAuditLog().back() == "'Task1' was rejected: insurance expired (now Rejected)");
}

TEST_CASE("all instances feed one shared audit log") {
    Fixture f;
    f.facade.registerDefinition(makeSequentialDefinition("seq", &f.workerRole, 1));
    std::string a = f.facade.createInstance("seq");
    std::string b = f.facade.createInstance("seq");
    f.facade.startInstance(a);
    f.facade.startInstance(b);
    CHECK(countContaining(f.facade.getAuditLog(), "'Task1' became available") == 2);
}

TEST_CASE("failed operations do not pollute the audit log") {
    Fixture f;
    std::string id = f.startedInstance();
    const std::size_t before = f.facade.getAuditLog().size();
    CHECK_THROWS(f.facade.startTask(id, "1"));
    CHECK_THROWS(f.facade.assignTask(id, "1", "ghost"));
    CHECK_THROWS(f.facade.completeTask("nope", "1"));
    CHECK(f.facade.getAuditLog().size() == before);
}

TEST_CASE("tasks WITHOUT the AuditedTask decorator publish no task events (characterisation)") {
    Fixture f;
    f.facade.registerDefinition(makeSequentialDefinition("plain", &f.workerRole, 1, /*audited=*/false));
    std::string id = f.facade.createInstance("plain");
    f.facade.startInstance(id);
    f.facade.assignTask(id, "1", "alice");
    f.facade.startTask(id, "1");
    f.facade.completeTask(id, "1");
    // the operations succeed (checked by absence of throws) but nothing is audited
    CHECK(f.facade.getAuditLog().empty());
}

TEST_CASE("getAuditLog returns the same content on consecutive calls") {
    Fixture f;
    f.startedInstance();
    CHECK(f.facade.getAuditLog() == f.facade.getAuditLog());
}

TEST_CASE("audit log scales: 100 instances produce 100 'became available' records") {
    Fixture f;
    f.facade.registerDefinition(makeSequentialDefinition("seq", &f.workerRole, 1));
    for (int i = 0; i < 100; ++i) f.facade.startInstance(f.facade.createInstance("seq"));
    CHECK(countContaining(f.facade.getAuditLog(), "became available") == 100);
}

} // TEST_SUITE

TEST_SUITE("Facade/Observer: metrics") {

TEST_CASE("metrics count one transition per distinct event") {
    Fixture f;
    std::string id = f.startedInstance();
    f.facade.assignTask(id, "1", "alice");
    std::string summary = f.facade.getMetricsSummary();
    CHECK(contains(summary, "State: 'Task1' became available (now Available), Transitions: 1"));
    CHECK(contains(summary, "State: 'Task1' was assigned (now Assigned), Transitions: 1"));
}

TEST_CASE("metrics aggregate identical events across instances") {
    Fixture f;
    f.facade.registerDefinition(makeSequentialDefinition("seq", &f.workerRole, 1));
    f.facade.startInstance(f.facade.createInstance("seq"));
    f.facade.startInstance(f.facade.createInstance("seq"));
    CHECK(contains(f.facade.getMetricsSummary(),
                   "'Task1' became available (now Available), Transitions: 2"));
}

TEST_CASE("metrics summary grows as work progresses and ends every line with a newline") {
    Fixture f;
    std::string id = f.startedInstance();
    const std::size_t s0 = f.facade.getMetricsSummary().size();
    f.facade.assignTask(id, "1", "alice");
    const std::string s1 = f.facade.getMetricsSummary();
    CHECK(s1.size() > s0);
    CHECK(s1[s1.size() - 1] == '\n');
}

TEST_CASE("metrics ignore failed operations") {
    Fixture f;
    std::string id = f.startedInstance();
    const std::string before = f.facade.getMetricsSummary();
    CHECK_THROWS(f.facade.completeTask(id, "1"));
    CHECK(f.facade.getMetricsSummary() == before);
}

} // TEST_SUITE

TEST_SUITE("Facade/Observer: per-instance wiring") {

TEST_CASE("every instance gets its own publisher yet shares the facade's listeners") {
    Fixture f;
    f.facade.registerDefinition(makeParallelDefinition("par", &f.workerRole, 2));
    std::string a = f.facade.createInstance("par");
    std::string b = f.facade.createInstance("par");
    f.facade.startInstance(a);
    // only A was started => only A's two tasks announced themselves
    CHECK(countContaining(f.facade.getAuditLog(), "became available") == 2);
    f.facade.startInstance(b);
    CHECK(countContaining(f.facade.getAuditLog(), "became available") == 4);
}

TEST_CASE("events published by an instance created later still reach the shared listeners") {
    Fixture f;
    f.facade.registerDefinition(makeSequentialDefinition("seq", &f.workerRole, 1));
    std::string a = f.facade.createInstance("seq");
    f.facade.startInstance(a);
    const std::size_t after1 = f.facade.getAuditLog().size();
    std::string b = f.facade.createInstance("seq");   // created AFTER activity happened
    f.facade.startInstance(b);
    CHECK(f.facade.getAuditLog().size() == after1 + 1);
}

} // TEST_SUITE