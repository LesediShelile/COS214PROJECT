// main.cpp - the test script AND the diagram definition in one place.
// Every theatre.step(...) below becomes a node in the activity diagram. Add,
// remove or reorder steps here and the diagram changes with them; the node that
// is highlighted is the step currently running.
//
// Two scenarios run back to back in the same window:
//   Part A - Hospital admission workflow
//   Part B - Legal case workflow

#include <string>
#include <stdexcept>
#include "include/ui/Desktop.h"
#include "include/ui/Playground.h"
#include "WorkItem.h"
#include "Task.h"
#include "SequentialStage.h"
#include "ParallelStage.h"
#include "Participant.h"
#include "Stage.h"

namespace {

// ---- helpers (shared by both scenarios) -----------------------------------
std::string state(WorkItem *w) { return w->getStateName(); }
QString qs(const std::string &s) { return QString::fromStdString(s); }

// "Released" = the parent stage has let this item start (available or beyond).
bool released(WorkItem *w) { return w->isAvailable() || state(w) != "Created"; }

// Push a task through its whole lifecycle.
void drive(WorkItem *w, Participant *who) {
    if (state(w) == "Created") w->makeAvailable();
    if (state(w) == "Available") w->assign(who);
    if (state(w) == "Assigned") w->start();
    if (state(w) == "Started") w->complete();
}


// Complete a task only after its parent stage has released it. This keeps the
// end-to-end demonstrations honest: a task cannot skip the workflow order.
void completeReleased(WorkItem *item, Participant *who) {
    if (!released(item))
        throw std::logic_error("Task is not released yet: " + item->getItemID());
    if (state(item) == "Available") item->assign(who);
    if (state(item) == "Assigned") item->start();
    if (state(item) == "Started") item->complete();
    if (state(item) != "Completed")
        throw std::logic_error("Task did not complete: " + item->getItemID() +
                               " (state: " + state(item) + ")");
}

// Re-evaluate the nested stages after a task changes state. The stage classes
// themselves decide what can be released: sequential stages release one child,
// while parallel stages release all their children together.
void refreshWorkflow(Stage *root) {
    if (root) root->activateChildren();
}

// ===========================================================================
// PART A - HOSPITAL
// ===========================================================================
// Everything the hospital steps share. Its first step resets it, so "Restart"
// in the GUI works.
struct HospitalCtx {
    Participant who;
    Participant reception, triageNurse, recordsClerk, bayTechnician;
    Participant admissionOfficer, attendingDoctor, cleaner, archivist;
    Stage *root = 0, *arrival = 0, *prep = 0, *admission = 0, *closeout = 0;
    Task *reg = 0, *triage = 0, *records = 0, *bay = 0, *approval = 0;
    Task *doctorTask = 0, *treatment = 0, *room = 0, *cleaning = 0, *archive = 0;

    HospitalCtx()
        : who("tester", "Test Runner", 0),
          reception("reception", "Receptionist", 0),
          triageNurse("triage-nurse", "Triage Nurse", 0),
          recordsClerk("records-clerk", "Records Clerk", 0),
          bayTechnician("bay-tech", "Treatment Bay Technician", 0),
          admissionOfficer("admission-officer", "Admission Officer", 0),
          attendingDoctor("doctor", "Attending Doctor", 0),
          cleaner("cleaner", "Cleaning Team", 0),
          archivist("archivist", "Records Archivist", 0) {}

    void reset() {
        delete root;
        root = arrival = prep = admission = closeout = 0;
        reg = triage = records = bay = approval = doctorTask = 0;
        treatment = room = cleaning = archive = 0;
    }
    ~HospitalCtx() { reset(); }
};

// Full hospital tree in one go, used by the end-to-end step.
void buildHospitalFull(HospitalCtx &c) {
    c.reset();
    c.root = new SequentialStage("full-root", "Hospital admission workflow");

    c.arrival = new SequentialStage("arrival-stage", "Arrival and triage");
    c.reg = new Task("register", "Reception registration", 0, 0);
    c.triage = new Task("triage", "Nurse triage and priority", 0, 0);
    c.arrival->add(c.reg);
    c.arrival->add(c.triage);

    c.prep = new ParallelStage("prep-stage", "Prepare admission in parallel");
    c.records = new Task("records", "Retrieve patient records", 0, 0);
    c.bay = new Task("bay", "Prepare treatment bay", 0, 0);
    c.prep->add(c.records);
    c.prep->add(c.bay);
    c.arrival->add(c.prep);
    c.root->add(c.arrival);

    c.admission = new SequentialStage("admission-stage", "Admission and treatment");
    c.approval = new Task("approval", "Request admission approval", 0, 0);
    c.doctorTask = new Task("doctor", "Doctor accepts case", 0, 0);
    c.treatment = new Task("treatment", "Assessment and treatment", 0, 0);
    c.room = new Task("room", "Allocate room / ICU", 0, 0);
    c.admission->add(c.approval);
    c.admission->add(c.doctorTask);
    c.admission->add(c.treatment);
    c.admission->add(c.room);
    c.root->add(c.admission);

    c.closeout = new SequentialStage("closeout-stage", "Discharge and closeout");
    c.cleaning = new Task("cleaning", "Clean treatment area", 0, 0);
    c.archive = new Task("archive", "Archive patient history", 0, 0);
    c.closeout->add(c.cleaning);
    c.closeout->add(c.archive);
    c.root->add(c.closeout);
}

void addHospitalScenario(Desktop &theatre, HospitalCtx &c) {
    auto &check = Desktop::check;
    auto &expectThrows = Desktop::expectThrows;

    // ------------------------------------------------------------------
    theatre.section("Hospital 1. Build the workflow (Composite)");

    theatre.step("Create the root stage", "Empty SequentialStage, no children yet", [&] {
        c.reset();
        c.root = new SequentialStage("root", "Admission workflow");
        check(c.root->getChildren().empty(), "A new stage should have no children");
        theatre.say("hospital root created");
    });

    theatre.step("Add tasks to a sequential stage", "register + triage inside 'arrival'", [&] {
        c.arrival = new SequentialStage("arrival", "Arrival and triage");
        c.reg = new Task("register", "Reception registration", 0, 0);
        c.triage = new Task("triage", "Nurse triage and priority", 0, 0);
        c.arrival->add(c.reg);
        c.arrival->add(c.triage);
        check(c.arrival->getChildren().size() == 2, "arrival should have 2 children");
    });

    theatre.step("Nest a parallel stage", "records + bay run side by side inside 'arrival'", [&] {
        c.prep = new ParallelStage("prep", "Prepare admission");
        c.records = new Task("records", "Retrieve patient records", 0, 0);
        c.bay = new Task("bay", "Prepare treatment bay", 0, 0);
        c.prep->add(c.records);
        c.prep->add(c.bay);
        c.arrival->add(c.prep);
        c.root->add(c.arrival);
        check(c.arrival->getChildren().size() == 3, "arrival should now have 3 children");
        check(c.root->getChildren().size() == 1, "root should have 1 child");
    });

    theatre.step("Add a second sequential stage", "approval -> treatment inside 'admission'", [&] {
        c.admission = new SequentialStage("admission", "Admission and treatment");
        c.approval = new Task("approval", "Request admission approval", 0, 0);
        c.treatment = new Task("treatment", "Assessment and treatment", 0, 0);
        c.admission->add(c.approval);
        c.admission->add(c.treatment);
        c.root->add(c.admission);
        check(c.root->getChildren().size() == 2, "root should have 2 stages");
    });

    // ------------------------------------------------------------------
    theatre.section("Hospital 2. Initial state and sequential gating");

    theatre.step("Tasks start in Created", "Nothing is released before the workflow starts", [&] {
        check(state(c.reg) == "Created", "register should be Created, was " + qs(state(c.reg)));
        check(state(c.triage) == "Created", "triage should be Created");
    });

    theatre.step("Start the workflow", "makeAvailable() + activateChildren() releases only the first task", [&] {
        c.root->makeAvailable();
        c.root->activateChildren();
        check(released(c.reg), "register should be released first");
        check(!released(c.triage), "triage must wait for register (sequential)");
        check(!released(c.approval), "approval must wait for the arrival stage");
    });

    // ------------------------------------------------------------------
    theatre.section("Hospital 3. Task lifecycle");

    theatre.step("Assign", "Available -> Assigned", [&] {
        if (state(c.reg) == "Created") c.reg->makeAvailable();
        c.reg->assign(&c.who);
        check(state(c.reg) == "Assigned", "expected Assigned, was " + qs(state(c.reg)));
    });

    theatre.step("Start", "Assigned -> Started", [&] {
        c.reg->start();
        check(state(c.reg) == "Started", "expected Started, was " + qs(state(c.reg)));
    });

    theatre.step("Complete", "Started -> Completed", [&] {
        c.reg->complete();
        check(state(c.reg) == "Completed", "expected Completed, was " + qs(state(c.reg)));
        check(c.reg->isFinished(), "a completed task should report isFinished()");
    });

    theatre.step("Next task is released", "Finishing 'register' opens 'triage'", [&] {
        c.root->activateChildren();
        check(released(c.triage), "triage should be released after register completes");
    });

    theatre.step("Illegal transition is refused", "Starting a task that is already completed must throw", [&] {
        expectThrows([&] { c.reg->start(); }, "start() on a completed task");
    });

    // ------------------------------------------------------------------
    theatre.section("Hospital 4. Parallel stage");

    theatre.step("Finish triage", "Opens the parallel prep stage", [&] {
        drive(c.triage, &c.who);
        c.root->activateChildren();
        check(c.triage->isFinished(), "triage should be finished");
    });

    theatre.step("Both parallel tasks open together", "records and bay are released at the same time", [&] {
        check(released(c.records), "records should be released");
        check(released(c.bay), "bay should be released");
    });

    theatre.step("One parallel task done, stage not done", "Stage waits for every child", [&] {
        drive(c.records, &c.who);
        c.root->activateChildren();
        check(c.records->isFinished(), "records should be finished");
        check(!c.prep->isFinished(), "prep must not finish while bay is open");
    });

    theatre.step("Last parallel task finishes the stage", "prep and then arrival complete", [&] {
        drive(c.bay, &c.who);
        c.root->activateChildren();
        check(c.prep->isFinished(), "prep should be finished");
        check(c.arrival->isFinished(), "arrival should be finished");
    });

    // ------------------------------------------------------------------
    theatre.section("Hospital 5. Reject and cancel");

    theatre.step("Next stage is released", "Admission opens after arrival", [&] {
        check(released(c.approval), "approval should be released once arrival is done");
    });

    theatre.step("Reject an assigned task", "reject(reason) on 'approval'", [&] {
        if (state(c.approval) == "Created") c.approval->makeAvailable();
        if (state(c.approval) == "Available") c.approval->assign(&c.who);
        c.approval->reject("Rejected by test");
        const std::string s = state(c.approval);
        theatre.say("approval is now " + qs(s));
        check(s == "Rejected" || s == "Available",
              "expected Rejected (or back to Available), was " + qs(s));
    });

    theatre.step("Cancel a task", "cancel() on 'treatment'", [&] {
        c.treatment->cancel();
        check(state(c.treatment) == "Cancelled", "expected Cancelled, was " + qs(state(c.treatment)));
    });

    // ------------------------------------------------------------------
    theatre.section("Hospital 6. Complete emergency admission scenario");

    theatre.step("A patient arrives at reception",
                 "Create a fresh case and release only the first arrival task", [&] {
        buildHospitalFull(c);
        c.root->makeAvailable();
        check(released(c.reg), "registration must be the first released task");
        check(!released(c.triage), "triage must wait for registration");
        theatre.say("Emergency case opened. Reception registration is ready; triage and admission remain locked.");
    });

    theatre.step("Reception registers the patient",
                 "Reception records the patient's details before clinical triage", [&] {
        completeReleased(c.reg, &c.reception);
        refreshWorkflow(c.root);
        check(released(c.triage), "triage should open after registration");
        theatre.say("Receptionist completed registration. The workflow now releases the triage nurse.");
    });

    theatre.step("Nurse assesses urgency",
                 "Triage is completed before preparation and admission can begin", [&] {
        completeReleased(c.triage, &c.triageNurse);
        refreshWorkflow(c.root);
        check(released(c.records) && released(c.bay), "records and bay preparation must open together");
        theatre.say("Triage complete. The patient is prioritised; records retrieval and bay preparation can now run in parallel.");
    });

    theatre.step("Retrieve the patient's medical records",
                 "The records clerk works independently while the bay is prepared", [&] {
        completeReleased(c.records, &c.recordsClerk);
        refreshWorkflow(c.root);
        check(c.records->isFinished(), "records task should be complete");
        check(!c.prep->isFinished(), "parallel preparation must wait for the bay task too");
        theatre.say("Medical history retrieved. The preparation stage remains open because the treatment bay is not ready yet.");
    });

    theatre.step("Prepare the treatment bay",
                 "The second parallel task finishes the preparation stage", [&] {
        completeReleased(c.bay, &c.bayTechnician);
        refreshWorkflow(c.root);
        check(c.prep->isFinished(), "preparation should finish after both parallel tasks");
        check(released(c.approval), "admission approval should now be released");
        theatre.say("Treatment bay is ready. Both preparation branches are complete, so admission approval can begin.");
    });

    theatre.step("Request admission approval",
                 "The admission officer reviews the completed triage and preparation", [&] {
        completeReleased(c.approval, &c.admissionOfficer);
        refreshWorkflow(c.root);
        check(released(c.doctorTask), "doctor acceptance should follow approval");
        theatre.say("Admission approved. The next sequential task is the doctor's acceptance.");
    });

    theatre.step("Doctor accepts the case",
                 "Clinical responsibility is accepted before treatment starts", [&] {
        completeReleased(c.doctorTask, &c.attendingDoctor);
        refreshWorkflow(c.root);
        check(released(c.treatment), "treatment should follow doctor acceptance");
        theatre.say("The attending doctor has accepted the case. Assessment and treatment are now available.");
    });

    theatre.step("Assess and treat the patient",
                 "The clinical task is completed before a room is allocated", [&] {
        completeReleased(c.treatment, &c.attendingDoctor);
        refreshWorkflow(c.root);
        check(released(c.room), "room allocation should follow treatment");
        theatre.say("Assessment and treatment recorded. The workflow moves to bed or ICU allocation.");
    });

    theatre.step("Allocate a ward or ICU room",
                 "The admission stage finishes only after room allocation", [&] {
        completeReleased(c.room, &c.admissionOfficer);
        refreshWorkflow(c.root);
        check(c.admission->isFinished(), "admission stage should be finished");
        check(released(c.cleaning), "closeout should begin after admission");
        theatre.say("A suitable room has been allocated. The admission stage is complete and closeout begins.");
    });

    theatre.step("Clean the treatment area",
                 "The cleaning task is the first sequential closeout task", [&] {
        completeReleased(c.cleaning, &c.cleaner);
        refreshWorkflow(c.root);
        check(released(c.archive), "archiving should follow cleaning");
        theatre.say("Treatment area cleaned. Patient records can now be archived.");
    });

    theatre.step("Archive the patient's admission record",
                 "The final task closes the workflow", [&] {
        completeReleased(c.archive, &c.archivist);
        refreshWorkflow(c.root);
        check(c.root->isFinished(), "hospital workflow should be finished");
        theatre.say("Admission closed successfully: registration, triage, parallel preparation, approval, treatment, allocation and closeout are complete.");
    });
}

// ===========================================================================
// PART B - LEGAL
// ===========================================================================
struct LegalCtx {
    Participant who;
    Participant paralegal, conflictOfficer, investigator, researcher;
    Participant witnessLiaison, associate, partner, filingClerk, counsel;
    Participant billingClerk, archivist;
    Stage *root = 0, *intake = 0, *discovery = 0, *litigation = 0, *closure = 0;
    Task *client = 0, *conflict = 0, *evidence = 0, *research = 0, *witness = 0;
    Task *draft = 0, *review = 0, *filing = 0, *hearing = 0;
    Task *judgment = 0, *invoice = 0, *archive = 0;

    LegalCtx()
        : who("lawyer", "Test Attorney", 0),
          paralegal("paralegal", "Paralegal", 0),
          conflictOfficer("conflicts", "Conflicts Officer", 0),
          investigator("investigator", "Case Investigator", 0),
          researcher("researcher", "Legal Researcher", 0),
          witnessLiaison("witness-liaison", "Witness Liaison", 0),
          associate("associate", "Associate Attorney", 0),
          partner("partner", "Reviewing Partner", 0),
          filingClerk("filing-clerk", "Court Filing Clerk", 0),
          counsel("counsel", "Court Counsel", 0),
          billingClerk("billing", "Billing Clerk", 0),
          archivist("legal-archivist", "Legal Records Clerk", 0) {}

    void reset() {
        delete root;
        root = intake = discovery = litigation = closure = 0;
        client = conflict = evidence = research = witness = 0;
        draft = review = filing = hearing = judgment = invoice = archive = 0;
    }
    ~LegalCtx() { reset(); }
};

// Full legal case tree in one go, used by the end-to-end step.
void buildLegalFull(LegalCtx &c) {
    c.reset();
    c.root = new SequentialStage("legal-full-root", "Legal case workflow");

    c.intake = new SequentialStage("intake-stage", "Client intake and conflict check");
    c.client = new Task("client", "Client intake interview", 0, 0);
    c.conflict = new Task("conflict", "Conflict of interest check", 0, 0);
    c.intake->add(c.client);
    c.intake->add(c.conflict);

    c.discovery = new ParallelStage("discovery-stage", "Investigate the case in parallel");
    c.evidence = new Task("evidence", "Gather evidence", 0, 0);
    c.research = new Task("research", "Legal research and precedents", 0, 0);
    c.witness = new Task("witness", "Interview witnesses", 0, 0);
    c.discovery->add(c.evidence);
    c.discovery->add(c.research);
    c.discovery->add(c.witness);
    c.intake->add(c.discovery);
    c.root->add(c.intake);

    c.litigation = new SequentialStage("litigation-stage", "Pleadings and court");
    c.draft = new Task("draft", "Draft pleadings", 0, 0);
    c.review = new Task("review", "Partner review and sign-off", 0, 0);
    c.filing = new Task("filing", "File with the court", 0, 0);
    c.hearing = new Task("hearing", "Attend hearing", 0, 0);
    c.litigation->add(c.draft);
    c.litigation->add(c.review);
    c.litigation->add(c.filing);
    c.litigation->add(c.hearing);
    c.root->add(c.litigation);

    c.closure = new SequentialStage("closure-stage", "Judgment and closure");
    c.judgment = new Task("judgment", "Record judgment or settlement", 0, 0);
    c.invoice = new Task("invoice", "Invoice the client", 0, 0);
    c.archive = new Task("archive-case", "Archive the case file", 0, 0);
    c.closure->add(c.judgment);
    c.closure->add(c.invoice);
    c.closure->add(c.archive);
    c.root->add(c.closure);
}

void addLegalScenario(Desktop &theatre, LegalCtx &c) {
    auto &check = Desktop::check;
    auto &expectThrows = Desktop::expectThrows;

    // ------------------------------------------------------------------
    theatre.section("Legal 1. Build the workflow (Composite)");

    theatre.step("Create the root stage", "Empty SequentialStage for a new legal case", [&] {
        c.reset();
        c.root = new SequentialStage("legal-root", "Legal case workflow");
        check(c.root->getChildren().empty(), "A new stage should have no children");
        theatre.say("legal root created");
    });

    theatre.step("Add tasks to a sequential stage", "client intake + conflict check inside 'intake'", [&] {
        c.intake = new SequentialStage("intake", "Client intake and conflict check");
        c.client = new Task("client", "Client intake interview", 0, 0);
        c.conflict = new Task("conflict", "Conflict of interest check", 0, 0);
        c.intake->add(c.client);
        c.intake->add(c.conflict);
        check(c.intake->getChildren().size() == 2, "intake should have 2 children");
    });

    theatre.step("Nest a parallel stage", "evidence + research run side by side inside 'intake'", [&] {
        c.discovery = new ParallelStage("discovery", "Investigate the case");
        c.evidence = new Task("evidence", "Gather evidence", 0, 0);
        c.research = new Task("research", "Legal research and precedents", 0, 0);
        c.discovery->add(c.evidence);
        c.discovery->add(c.research);
        c.intake->add(c.discovery);
        c.root->add(c.intake);
        check(c.intake->getChildren().size() == 3, "intake should now have 3 children");
        check(c.root->getChildren().size() == 1, "root should have 1 child");
    });

    theatre.step("Add a second sequential stage", "draft -> review -> filing inside 'litigation'", [&] {
        c.litigation = new SequentialStage("litigation", "Pleadings and court");
        c.draft = new Task("draft", "Draft pleadings", 0, 0);
        c.review = new Task("review", "Partner review and sign-off", 0, 0);
        c.filing = new Task("filing", "File with the court", 0, 0);
        c.litigation->add(c.draft);
        c.litigation->add(c.review);
        c.litigation->add(c.filing);
        c.root->add(c.litigation);
        check(c.litigation->getChildren().size() == 3, "litigation should have 3 children");
        check(c.root->getChildren().size() == 2, "root should have 2 stages");
    });

    // ------------------------------------------------------------------
    theatre.section("Legal 2. Initial state and sequential gating");

    theatre.step("Tasks start in Created", "Nothing is released before the case is opened", [&] {
        check(state(c.client) == "Created", "client intake should be Created, was " + qs(state(c.client)));
        check(state(c.conflict) == "Created", "conflict check should be Created");
    });

    theatre.step("Open the case", "makeAvailable() + activateChildren() releases only client intake", [&] {
        c.root->makeAvailable();
        c.root->activateChildren();
        check(released(c.client), "client intake should be released first");
        check(!released(c.conflict), "conflict check must wait for client intake (sequential)");
        check(!released(c.draft), "drafting must wait for the intake stage");
    });

    // ------------------------------------------------------------------
    theatre.section("Legal 3. Task lifecycle");

    theatre.step("Assign", "Available -> Assigned", [&] {
        if (state(c.client) == "Created") c.client->makeAvailable();
        c.client->assign(&c.who);
        check(state(c.client) == "Assigned", "expected Assigned, was " + qs(state(c.client)));
    });

    theatre.step("Start", "Assigned -> Started", [&] {
        c.client->start();
        check(state(c.client) == "Started", "expected Started, was " + qs(state(c.client)));
    });

    theatre.step("Complete", "Started -> Completed", [&] {
        c.client->complete();
        check(state(c.client) == "Completed", "expected Completed, was " + qs(state(c.client)));
        check(c.client->isFinished(), "a completed task should report isFinished()");
    });

    theatre.step("Next task is released", "Finishing client intake opens the conflict check", [&] {
        c.root->activateChildren();
        check(released(c.conflict), "conflict check should be released after intake completes");
    });

    theatre.step("Illegal transition is refused", "Starting a task that is already completed must throw", [&] {
        expectThrows([&] { c.client->start(); }, "start() on a completed task");
    });

    // ------------------------------------------------------------------
    theatre.section("Legal 4. Parallel discovery");

    theatre.step("Clear the conflict check", "Opens the parallel discovery stage", [&] {
        drive(c.conflict, &c.who);
        c.root->activateChildren();
        check(c.conflict->isFinished(), "conflict check should be finished");
    });

    theatre.step("Both discovery tasks open together", "evidence and research are released at the same time", [&] {
        check(released(c.evidence), "evidence gathering should be released");
        check(released(c.research), "legal research should be released");
    });

    theatre.step("One discovery task done, stage not done", "Stage waits for every child", [&] {
        drive(c.evidence, &c.who);
        c.root->activateChildren();
        check(c.evidence->isFinished(), "evidence gathering should be finished");
        check(!c.discovery->isFinished(), "discovery must not finish while research is open");
    });

    theatre.step("Last discovery task finishes the stage", "discovery and then intake complete", [&] {
        drive(c.research, &c.who);
        c.root->activateChildren();
        check(c.discovery->isFinished(), "discovery should be finished");
        check(c.intake->isFinished(), "intake should be finished");
    });

    // ------------------------------------------------------------------
    theatre.section("Legal 5. Reject and cancel");

    theatre.step("Litigation stage is released", "Drafting opens after intake", [&] {
        check(released(c.draft), "drafting should be released once intake is done");
    });

    theatre.step("Reject at partner review", "Finish the draft, then reject(reason) on 'review'", [&] {
        drive(c.draft, &c.who);
        c.root->activateChildren();
        check(c.draft->isFinished(), "draft should be finished before review");
        if (state(c.review) == "Created") c.review->makeAvailable();
        if (state(c.review) == "Available") c.review->assign(&c.who);
        c.review->reject("Pleadings need revision");
        const std::string s = state(c.review);
        theatre.say("review is now " + qs(s));
        check(s == "Rejected" || s == "Available",
              "expected Rejected (or back to Available), was " + qs(s));
    });

    theatre.step("Cancel a task", "cancel() on 'filing' - the client withdrew", [&] {
        c.filing->cancel();
        check(state(c.filing) == "Cancelled", "expected Cancelled, was " + qs(state(c.filing)));
    });

    // ------------------------------------------------------------------
    theatre.section("Legal 6. Complete civil case scenario");

    theatre.step("A new client opens a case",
                 "Build the full case tree and release only the client interview", [&] {
        buildLegalFull(c);
        c.root->makeAvailable();
        check(released(c.client), "client interview should be the first task");
        check(!released(c.conflict), "conflict check must wait for the interview");
        theatre.say("New civil matter opened. The paralegal can begin intake; conflict screening and legal work are not yet released.");
    });

    theatre.step("Paralegal records the client's instructions",
                 "The facts, parties, requested outcome and supporting documents are captured", [&] {
        completeReleased(c.client, &c.paralegal);
        refreshWorkflow(c.root);
        check(released(c.conflict), "conflict screening should follow intake");
        theatre.say("Client instructions captured. The case can now be checked for conflicts of interest.");
    });

    theatre.step("Run the conflict-of-interest check",
                 "The firm checks whether it can act for this client", [&] {
        completeReleased(c.conflict, &c.conflictOfficer);
        refreshWorkflow(c.root);
        check(released(c.evidence) && released(c.research) && released(c.witness),
              "all discovery tasks should be released together");
        theatre.say("No blocking conflict remains. Evidence gathering, legal research and witness interviews can proceed in parallel.");
    });

    theatre.step("Investigators gather the evidence",
                 "The evidence branch progresses independently", [&] {
        completeReleased(c.evidence, &c.investigator);
        refreshWorkflow(c.root);
        check(!c.discovery->isFinished(), "discovery must wait for research and witness work");
        theatre.say("Documents and other evidence have been collected. Discovery remains active while the other two branches continue.");
    });

    theatre.step("Research relevant law and precedents",
                 "The researcher prepares the legal authorities for the matter", [&] {
        completeReleased(c.research, &c.researcher);
        refreshWorkflow(c.root);
        check(!c.discovery->isFinished(), "discovery must still wait for witness interviews");
        theatre.say("Legal research is complete. The witness interview branch is still outstanding.");
    });

    theatre.step("Interview the witnesses",
                 "The final parallel discovery task completes the discovery stage", [&] {
        completeReleased(c.witness, &c.witnessLiaison);
        refreshWorkflow(c.root);
        check(c.discovery->isFinished(), "discovery should finish after all three branches");
        check(released(c.draft), "pleadings should open after discovery");
        theatre.say("Witness statements are recorded. All discovery branches are complete, so pleadings can be drafted.");
    });

    theatre.step("Draft the pleadings",
                 "The associate uses the intake, evidence and research outputs", [&] {
        completeReleased(c.draft, &c.associate);
        refreshWorkflow(c.root);
        check(released(c.review), "partner review should follow drafting");
        theatre.say("First draft prepared using the case facts and discovery results. The draft is sent for partner review.");
    });

    theatre.step("Partner reviews and signs off",
                 "The reviewing partner checks the pleadings before filing", [&] {
        completeReleased(c.review, &c.partner);
        refreshWorkflow(c.root);
        check(released(c.filing), "court filing should follow sign-off");
        theatre.say("Partner review approved. The pleadings are ready to be filed with the court.");
    });

    theatre.step("File the matter with the court",
                 "The filing clerk submits the approved documents", [&] {
        completeReleased(c.filing, &c.filingClerk);
        refreshWorkflow(c.root);
        check(released(c.hearing), "hearing should follow filing");
        theatre.say("Court filing completed. The matter can proceed to the hearing stage.");
    });

    theatre.step("Attend the hearing",
                 "Counsel presents the matter and the hearing is recorded", [&] {
        completeReleased(c.hearing, &c.counsel);
        refreshWorkflow(c.root);
        check(c.litigation->isFinished(), "litigation stage should be finished");
        check(released(c.judgment), "case closure should follow the hearing");
        theatre.say("Hearing completed. The litigation stage is finished and the outcome can be recorded.");
    });

    theatre.step("Record the judgment or settlement",
                 "The official outcome is added to the case record", [&] {
        completeReleased(c.judgment, &c.partner);
        refreshWorkflow(c.root);
        check(released(c.invoice), "billing should follow the recorded outcome");
        theatre.say("Judgment or settlement recorded. The client account can now be finalised.");
    });

    theatre.step("Prepare the client invoice",
                 "The billing clerk closes the financial part of the matter", [&] {
        completeReleased(c.invoice, &c.billingClerk);
        refreshWorkflow(c.root);
        check(released(c.archive), "archiving should follow invoicing");
        theatre.say("Invoice prepared. The final administrative task is to archive the case file.");
    });

    theatre.step("Archive the completed case",
                 "The final task closes the legal workflow", [&] {
        completeReleased(c.archive, &c.archivist);
        refreshWorkflow(c.root);
        check(c.root->isFinished(), "legal case workflow should be finished");
        theatre.say("Case closed: intake, conflict screening, parallel discovery, pleadings, court process, outcome, billing and archiving are complete.");
    });
}

} // namespace

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    Desktop theatre("TIVIDY | Workflow tests");
    HospitalCtx hospital;
    LegalCtx legal;

    theatre.tab("Hospital admission");        // Part A
    addHospitalScenario(theatre, hospital);

    theatre.tab("Legal case");                // Part B
    addLegalScenario(theatre, legal);

    Playground playground;                    // must be declared after theatre
    theatre.addTab("Playground", &playground);

    theatre.run();
    return app.exec();
}