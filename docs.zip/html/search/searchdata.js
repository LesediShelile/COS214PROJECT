var indexSectionsWithContent =
{
  0: "1abcdefghilmopqrstw🌿🏥🐳👥📁📑📚🔧🗂🙌🚀🧩🧪",
  1: "m",
  2: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Pages"
};

