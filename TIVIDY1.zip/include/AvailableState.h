#ifndef Available_H
#define Available_H

#include <iostream>
#include <string>

#include "TaskState.h"

/**
 * @brief State of a task that is ready to be assigned (State pattern).
 *
 * From here the task can be assigned, rejected or cancelled.
 */
class Available  : public TaskState {

    public: 

        /**
         * @brief Assigns a participant and moves the task to Assigned.
         * @param task The task this state belongs to.
         * @param participant The participant to assign. If nullptr, the task stays Available.
         */
        void assign (Task* task, Participant* participant) override;

        /**
         * @brief Rejects the task, saves the reason and moves it to RejectedState.
         * @param task The task this state belongs to.
         * @param reason Why the task was rejected.
         */
        void reject (Task* task, std::string reason) override;

        /**
         * @brief Cancels the task and moves it to Cancelled.
         * @param task The task this state belongs to.
         */
        void cancel (Task* task) override;

        /**
         * @brief Gets the name of this state.
         * @return "Available".
         */
        std::string getName() const override;

        /**
         * @brief Creates a copy of this state (Prototype pattern).
         * @return A new Available.
         */
        TaskState* clone() const override;

        /**
         * @brief An Available task is ready to be assigned.
         * @return true.
         */
        bool isAvailable() const override { return true; }
};
#endif